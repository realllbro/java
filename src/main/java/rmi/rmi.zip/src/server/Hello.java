package server;

public interface Hello extends java.rmi.Remote {
	public String sayHello(String name) throws java.rmi.RemoteException;
}
